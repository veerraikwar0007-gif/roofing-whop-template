# Roofing Whop Website template

Responsive Next.js starter for a roofing-company sales demo, designed to deploy as a Whop Website after importing through the supported Whop AI / CLI workflow.

## Included
- Responsive marketing site: services, service-area placeholder, financing CTA, review placeholders, estimate form.
- Estimate form server proxy to Whop Leads API (confirm current API payload/version in Whop docs before use).
- Checkout page using Whop Elements (`Checkout`, `CheckoutElement`, `ExpressCheckoutElement`, `BrandingElement`), never custom card fields.
- Three plan placeholders: $149 inspection, $500 deposit, $349 flat-rate repair.
- Estimate event tracking hook (`estimate_requested`) and service hover/click tracking (`service_viewed`). Add the `deposit_started` event in the deposit plan-selection action and confirm it in Pixel dashboard.
- Editable demo brand, contact, service-area and testimonial placeholders.

## Setup
1. Install Node.js 20+ and run `npm install`.
2. Set env vars using `.env.example`; keep `WHOP_API_KEY` server-side only.
3. Create the three plans in Whop dashboard/sandbox; copy plan IDs into the environment.
4. Confirm the current Leads API schema and `Api-Version-Date` against official Whop documentation; this starter's endpoint/payload may need updating to match your account's current API.
5. Replace demo business content, locations, phone, reviews and financing language. Never publish fabricated reviews.
6. `npm run dev`, test form and sandbox checkout.
7. For Whop Websites deployment, use Whop's official quickstart/AI/CLI process for your account and deploy; this repository itself is not a live deployment.

## Card-on-file and final invoice workflow (implementation guide)
Use a setup-mode Payment Element at the deposit step to obtain a Whop confirmation token; POST it to your server and create a setup intent using Whop's Setup Intents API. Check the setup-intent status is `succeeded` before using its saved payment-method ID. Then create the final invoice using Whop Invoices API with the saved method and explicit customer consent/mandate, or set manual collection and send the invoice. The template intentionally does not auto-charge a stored card or create live invoices without merchant credentials, tested consent handling, and a confirmed current API schema.

## Pixel events
`service_viewed` and `estimate_requested` are wired. Wire `deposit_started` to the deposit selection/button interaction once plan selection UX is finalized. Verify custom event payloads in Whop Pixel dashboard. Page views and Whop checkout events are automatic on Whop-hosted website/checkout.

## Deployment / submission limitations
A live `whop.app` deployment, account plans, successful sandbox checkout, real Lead creation verification, invoice creation, and screen recording require access to the user's Whop account, API credentials and deployment session. They cannot be truthfully claimed from this source-only build.
